import './assets/styles/styles.scss'
import 'swiper/swiper-bundle.min.css'
import 'glightbox/dist/css/glightbox.min.css'
import 'bootstrap/dist/css/bootstrap-grid.min.css'

import 'swiper/swiper-bundle.min'
import './assets/js/main'
import 'glightbox/dist/js/glightbox.min'
import 'readmore-js/dist/readmore'


